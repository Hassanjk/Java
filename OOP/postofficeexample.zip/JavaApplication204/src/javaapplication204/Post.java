
package javaapplication204;


class Post {
    String message;
    String source;
    String destination;

    public Post(String message, String source, String destination) {
        this.message = message;
        this.source = source;
        this.destination = destination;
    }
    
}
